﻿/*
Navicat MySQL Data Transfer

Source Server         : javaee
Source Server Version : 50096
Source Host           : localhost:3306
Source Database       : xscj

Target Server Type    : MYSQL
Target Server Version : 50096
File Encoding         : 65001

Date: 2018-06-06 14:57:47
*/
create database xscj;
use xscj;
SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `cjb`
-- ----------------------------
DROP TABLE IF EXISTS `cjb`;
CREATE TABLE `cjb` (
  `xh` char(11) NOT NULL,
  `kch` char(3) NOT NULL,
  `cj` int default NULL,
  `xf` int default NULL,
  PRIMARY KEY  (`xh`,`kch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cjb
-- ----------------------------

-- ----------------------------
-- Table structure for `dlb`
-- ----------------------------
DROP TABLE IF EXISTS `dlb`;
CREATE TABLE `dlb` (
  `id` int NOT NULL default '0',
  `xh` char(11) default NULL,
  `kl` char(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dlb
-- ----------------------------
INSERT INTO `dlb` VALUES ('1', '123', '123');

-- ----------------------------
-- Table structure for `kcb`
-- ----------------------------
DROP TABLE IF EXISTS `kcb`;
CREATE TABLE `kcb` (
  `kch` char(3) NOT NULL,
  `kcm` char(12) default NULL,
  `kxxq` smallint(6) default NULL,
  `xs` int default NULL,
  `xf` int default NULL,
  PRIMARY KEY  (`kch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kcb
-- ----------------------------
INSERT INTO `kcb` VALUES ('1', '软件工程', '1', '30', '5');

-- ----------------------------
-- Table structure for `xsb`
-- ----------------------------
DROP TABLE IF EXISTS `xsb`;
CREATE TABLE `xsb` (
  `xh` char(11) NOT NULL,
  `xm` char(8) NOT NULL,
  `xb` tinyint(4) NOT NULL,
  `cssj` date default NULL,
  `zy_id` int default NULL,
  `zxf` int default NULL,
  `bz` varchar(500) default NULL,
  `zp` blob default NULL,
  PRIMARY KEY  (`xh`),
  KEY `TK1` (`zy_id`),
  CONSTRAINT `TK1` FOREIGN KEY (`zy_id`) REFERENCES `zyb` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xsb
-- ----------------------------

-- ----------------------------
-- Table structure for `zyb`
-- ----------------------------
DROP TABLE IF EXISTS `zyb`;
CREATE TABLE `zyb` (
  `id` int NOT NULL auto_increment,
  `zym` char(12) NOT NULL COMMENT '专业名',
  `rs` int default NULL COMMENT '人数',
  `fdy` char(8) default NULL COMMENT '辅导员',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of zyb
-- ----------------------------
INSERT INTO `zyb` VALUES ('1', '软件1402', '40', '某某');
INSERT INTO `zyb` VALUES ('2', '软件1401', '39', '某某');
